
import React from 'react';

interface MediaCardProps {
  title: string;
  type: 'image' | 'video';
  url?: string;
  isLoading: boolean;
  statusText?: string;
}

export const MediaCard: React.FC<MediaCardProps> = ({ title, type, url, isLoading, statusText }) => {
  return (
    <div className="glass rounded-2xl overflow-hidden flex flex-col h-full group">
      <div className="p-4 border-b border-white/10 flex justify-between items-center">
        <h3 className="font-semibold text-slate-200">{title}</h3>
        <span className="text-xs uppercase tracking-wider px-2 py-1 bg-white/5 rounded text-slate-400">
          {type}
        </span>
      </div>
      
      <div className="relative flex-grow flex items-center justify-center bg-slate-900/50 aspect-video">
        {isLoading ? (
          <div className="flex flex-col items-center gap-4 text-center px-6">
            <div className="shimmer w-full h-full absolute inset-0 opacity-20"></div>
            <div className="w-12 h-12 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin"></div>
            <div>
              <p className="text-sm font-medium text-slate-300">Generating {type}...</p>
              <p className="text-xs text-slate-500 mt-1">{statusText || 'Processing cinematic details'}</p>
            </div>
          </div>
        ) : url ? (
          type === 'image' ? (
            <img 
              src={url} 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
            />
          ) : (
            <video 
              src={url} 
              controls 
              className="w-full h-full object-cover"
              autoPlay
              loop
              muted
            />
          )
        ) : (
          <div className="text-slate-600 flex flex-col items-center gap-2">
            <svg className="w-12 h-12 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-sm">Ready for generation</p>
          </div>
        )}
      </div>
      
      {url && (
        <div className="p-4 bg-slate-800/50 flex justify-end">
          <a 
            href={url} 
            download={`product-${type}.png`}
            className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Download High Res
          </a>
        </div>
      )}
    </div>
  );
};
